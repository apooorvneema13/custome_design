import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ExcelService } from './../../../shared/services/Export/excel.service';
import { ProductService } from './services/product.service';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from "@angular/common/http";
var api_Url='http://139.59.21.147:8080';


@Component({
  selector: 'my-products',
  templateUrl: './my-products.component.html',
  styleUrls: ['./my-products.component.scss']
})

export class MyProductsComponent implements OnInit {
  public objVendormodel: any;
  param: any;
  isRecommendModalShow: boolean = false;
  isAddNewProductShow: boolean = false;
  isMoreProductInformationModalShow: boolean = false;
  isAddProductShow: boolean = false;
  isMyProductsShow: boolean = true;
  isCategoryShow1: boolean = false;
  isCategoryShow2: boolean = false;
  isCategoryShow3: boolean = false;
  token:any;
  data: any;
  chartOptions: any;
  btnExport: string = "";
  TabSelection: string = "All";
  JsonData: any[] = [];
  SelectAll: boolean = false;
  ActionSelection:string="";
  constructor(private router: Router,
    private http: HttpClient,
    private excelService: ExcelService,
    public productService: ProductService
    ) {
  }
  ngOnInit(): void {
//alert(this.token);
this.token =localStorage.getItem('token');  
/*let headers = new HttpHeaders();
headers = headers.set('x-access-token','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNjQ4MTA4NzA3LCJleHAiOjE2NDgxOTUxMDd9.8kD9gNdrTKhZbPLFOd0Rr5hcKlRprXRgQ2-cI-L1j58');*/
/* let headers=new HttpHeaders().set(
      "x-access-token",
       'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNjQ4MTA4NzA3LCJleHAiOjE2NDgxOTUxMDd9.8kD9gNdrTKhZbPLFOd0Rr5hcKlRprXRgQ2-cI-L1j58'
    );*/
  //const headers = new HttpHeaders().set('x-access-token', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNjQ4MTA4NzA3LCJleHAiOjE2NDgxOTUxMDd9.8kD9gNdrTKhZbPLFOd0Rr5hcKlRprXRgQ2-cI-L1j58');
/*const header = {
        headers: {
            "x-access-token": 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNjQ4MTA4NzA3LCJleHAiOjE2NDgxOTUxMDd9.8kD9gNdrTKhZbPLFOd0Rr5hcKlRprXRgQ2-cI-L1j58',
            "content-type": "application/json"
        }
      }*/
/*var headers = new Headers();
headers.append('x-access-token','rwerewrewr');*/
 //const headers = { 'x-access-token': 'rwerewrewr' };
/*var headers = new Headers();
 const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' ,'x-access-token': 'eqee'})
};*/


/*const headers ={'x-access-token': 'eqee'};
const config={headers:headers};*/



/* this.http.post(api_Url+'/api/products/5', 
)*/
debugger;

let headers = new HttpHeaders({
  'Content-Type': 'application/json',
  'x-access-token':  this.token });
let options = { headers: headers };

this.http.post(api_Url+'/api/products',null,options)
    .subscribe((response:any) => {
      if(response.statuscode=='404') 
       {

        alert(response.message);
        
       }
      else if(response.statuscode=='200')
      {  
        this.JsonData.push(response.data);
        
      }
    });

    
   








    // this.JsonData.push(
    //   {
    //     "Selected": false,
    //     "Name": "REVLON",
    //     "SKU": "BM 1710ST",
    //     "Created": "18 Dec 2021",
    //     "Price": "777777.00",
    //     "SalePrice": "677777.00",
    //     "AvailablePrice": "-",
    //     "Available": "666",
    //     "Visible": "Yes",
    //     "PRKit": "Yes",
    //     "Active": false,
    //     "Action":""
    //   })

   /* this.JsonData.push(
      {
        "Selected": false,
        "Name": "DIOR",
        "SKU": "BM 1710ST",
        "Created": "18 Dec 2021",
        "Price": "777777.00",
        "SalePrice": "677777.00",
        "AvailablePrice": "-",
        "Available": "666",
        "Visible": "Yes",
        "PRKit": "Yes",
        "Active": true,
        "Action":""
      })
    this.JsonData.push(
      {
        "Selected": false,
        "Name": "CHANEL",
        "SKU": "BM 1710ST",
        "Created": "18 Dec 2021",
        "Price": "777777.00",
        "SalePrice": "677777.00",
        "AvailablePrice": "-",
        "Available": "666",
        "Visible": "Yes",
        "PRKit": "Yes",
        "Active": false,
        "Action":""
      })*/
    this.data = {
      labels: ['A', 'B'],
      datasets: [
        {
          data: [300, 50],
          backgroundColor: [
            "#DE3731",
            "#F6F6F6",
          ],
        }
      ]
    };

    this.chartOptions = this.getLightTheme();
  }

  onProductCreate(product:any) 
  {

    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'x-access-token':  this.token });
    let options = { headers: headers };

    let param = {
      name :this.objVendormodel.name,
      sale_price : this.objVendormodel.sale_price,
      short_description : this.objVendormodel.short_description,
    discount : this.objVendormodel.discount,
     details : this.objVendormodel.details,
     brand : this.objVendormodel.brand,
     price : this.objVendormodel.price,
     influencer : this.objVendormodel.influencer
    }


    //console.log("data",registration)
    //console.log("data",{username:username,password:password,email_address:email_address,name_of_business:name_of_business,industry:industry,contact_person_name:contact_person_name,phone_number:phone_number});



    this.http
       .post("http://139.59.21.147:8080/api/products", this.param ,options )
      .subscribe((response: any) => {
        if (response.statuscode == '404') {
          alert(response.message);
        }
        else if (response.statuscode == '200') {
          alert(response.data[0].id);
          console.log("resp", response.data.id);
        }
      });

  }

  getLightTheme() {
    return {
      plugins: {
        legend: {
          display: false
        }
      }
    }
  }

  onClickForGender(genderType:any) {
    this.productService.gender =  genderType;
    this.isCategoryShow1 = true;

  }

  onClickCategory1() {
    this.isCategoryShow2 = true;
  }

  onClickCategory2() {
    this.isCategoryShow3 = true;
  }

  onClickRecommend() {
    this.isRecommendModalShow = !this.isRecommendModalShow;
  }

  onClickAdd() {
    this.isMyProductsShow = false;
    this.isAddProductShow = true;
  }
  onClickMoreProductInformation() {
    
  }

  onClickMoreProductInformation1() {
    debugger;
    let data = {
      name :this.objVendormodel.name,
      sale_price : this.objVendormodel.sale_price,
      short_description : this.objVendormodel.short_description,
      discount : this.objVendormodel.discount,
      details : this.objVendormodel.details,
      brand : this.objVendormodel.brand,
      price : this.objVendormodel.price,
      influencer : this.objVendormodel.influencer
    }
    console.log("sf",data)
    this.productService.productBasicDetails = data;

    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'x-access-token':  this.token });
    let options = { headers: headers };

    this.http
       .post("http://139.59.21.147:8080/api/products", this.productService.productBasicDetails , options )
      .subscribe((response: any) => {
        debugger;
        if (response.statuscode == '404') {
          alert(response.message);
        }
        else if (response.statuscode == '200') {
          alert(response.data[0].id);
          console.log("resp", response.data.id);
        }
      });








    this.isMoreProductInformationModalShow = !this.isMoreProductInformationModalShow;
  }

  onClickCreateNewProduct() {
    this.isAddProductShow = false;
    this.isAddNewProductShow = true;
  }
  gotoProductinfo() {
    document.getElementById("ProductInformation-tab")?.click();
  }
  Downloadfile() {
    let temp = this.JsonData;
    for (let index = 0; index < temp.length; index++) {
      delete temp[index].Selected;
      delete temp[index].Action;
    }
    if (this.btnExport == "Excel") {
      this.excelService.exportAsExcelFile(temp, 'Products');
    }
    else if (this.btnExport == "CSV") {
      this.excelService.exportAsCSVFile(temp, 'Products')
    }

  }

  onTabSelection(TabSelection: string) {
    this.TabSelection = TabSelection;
  }
  onSelectAll() {
    this.JsonData.forEach(element => {
      element.Selected = this.SelectAll;
    });
  }
  Oneditproduct(Item:any)
  {
     if(Item.Action=="Edit")
     {
      this.isMyProductsShow = false;
      this.isAddNewProductShow = true;
      setTimeout(() => {
        document.getElementById("ProductInformation-tab")?.click();  
      }, 30);
      
    }
    
  }
}
