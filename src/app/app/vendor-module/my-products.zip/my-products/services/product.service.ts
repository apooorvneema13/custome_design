import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor() { }
  public gender:string = "";
  public productBasicDetails: any ;
}
